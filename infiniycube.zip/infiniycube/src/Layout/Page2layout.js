import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import {Container,Row,Col,Table} from 'react-bootstrap'
import {Bar,Line,Pie} from 'react-chartjs-2';

function Page2layout(props) {
    //console.log(props.postdata);
    let post_data= [];
    let postid =[];
    let count_array=[];
    let date=[];
    let dailycomment=[];
    for(let key in props.commentdic){
        //console.log(key)
        postid.push(key.slice(0,12));
        count_array.push(props.commentdic[key])

    }
    for(let key in props.dailycommentdic){
        //console.log(key)
        date.push(key);
        dailycomment.push(props.dailycommentdic[key])

    }
    console.log(count_array)
    let table_data=[];
   
        //console.log(props.postdata)
        post_data=props.postdata;
        for (let i in post_data) {
            
            table_data.push(
                <tr>
                  <td> {post_data[i].post_id} </td> 
                  <td> {post_data[i].created_datetime} </td> 
                  <td> {post_data[i].post} </td> 
                  <td> {post_data[i].post_likes} </td> 
                  <td> {post_data[i].share_count} </td> 
                  <td> {post_data[i].action_link} </td> 
                  <td> {post_data[i].username} </td> 
                </tr>
                )
        } 
        
    let state = {
        
        labels: postid,
        datasets: [
          {
            label: 'comments',
            backgroundColor: 'rgba(75,192,192,1)',
            borderColor: 'rgba(0,0,0,1)',
            borderWidth: 1,
            data: count_array
          }
        ]
      }
      let state1 = {
        
        labels: date,
        datasets: [
          {
            label: 'comments',
            backgroundColor: 'rgba(75,192,192,1)',
            borderColor: 'rgba(0,0,0,1)',
            borderWidth: 1,
            data: dailycomment
          }
        ]
      }
      const state2 = {
        labels: ['a', 'b', 'c',
                 'd', 'e'],
        datasets: [
          {
            label: 'Comments',
            backgroundColor: [
              '#B21F00',
              '#C9DE00',
              '#2FDE00',
              '#00A6B4',
              '#6800B4'
            ],
            hoverBackgroundColor: [
            '#501800',
            '#4B5000',
            '#175000',
            '#003350',
            '#35014F'
            ],
            data: [65, 59, 80, 81, 56]
          }
        ]
      }
  return (
    <div>
        <Container>
            <Row>
                <Col sm={6}>
                    <Pie
                        data={state2}
                        options={{
                            title:{
                            display:true,
                            text:'Likes',
                            fontSize:20
                            },
                            legend:{
                            display:true,
                            position:'right'
                            }
                        }}
                    />

                </Col>
                <Col sm={6}>
                    <Bar
                        data={state}
                        options={{
                            title:{
                            display:true,
                            text:'Comment count',
                            fontSize:20
                            },
                            legend:{
                            display:true,
                            position:'right'
                            }
                        }}
                    />
                </Col>
            </Row>
            <Row>
                <Col >
                    <Line
                        data={state1}
                        options={{
                            title:{
                            display:true,
                            text:'Daily Comments',
                            fontSize:20
                            },
                            legend:{
                            display:true,
                            position:'right'
                            }
                        }}
                    />
                </Col>
            </Row>
            <Row>
                <Col >
                    <Table striped bordered hover>
                        <thead>
                            <tr>
                            <th>Post Id</th>
                            <th>Created time</th>
                            <th>Post </th>
                            <th>Post Like</th>
                            <th>Share Count</th>
                            <th>Action Link</th>
                            <th>Username</th>
                            </tr>
                        </thead>
                        <tbody>
                            {table_data}
                        </tbody>
                    </Table>
                </Col>
            </Row>
        </Container>
    </div>
  )
}

export default Page2layout
