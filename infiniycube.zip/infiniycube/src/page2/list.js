import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemSecondaryAction from "@material-ui/core/ListItemSecondaryAction";
import ListItemText from "@material-ui/core/ListItemText";
import Checkbox from "@material-ui/core/Checkbox";
import FacebookIcon from "@material-ui/icons/Facebook";
import TwitterIcon from "@material-ui/icons/Twitter";
import YouTubeIcon from "@material-ui/icons/YouTube";
import RedditIcon from "@material-ui/icons/Reddit";
import Button from "@material-ui/core/Button";
import Grid from "@material-ui/core/Grid";
import ArrowForwardIosIcon from "@material-ui/icons/ArrowForwardIos";
import Badge from "@material-ui/core/Badge";
import { withStyles } from "@material-ui/core/styles";
import IconButton from "@material-ui/core/IconButton";

const StyledBadge = withStyles((theme) => ({
  badge: {
    right: -3,
    top: 10,
    border: `2px solid  #1f618d `,
    padding: "0 4px",
    height: "30px",
    width: "30px",
    backgroundColor: " #1f618d ",
    borderRadius: "15px"
  }
}))(Badge);

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    maxWidth: 360,
    backgroundColor: theme.palette.background.paper
  },
  transferButton: {
    width: "100%",
    height: "100%",
    margin: "5px",
    padding: "5px",
    maxWidth: "30px"
  },
  contentBox: {
    width: "100%",
    height: "200px",
    border: "2px solid black",
    borderRadius: "10px",
    padding: "20px"
  },
  badgeContainer: {
    width: "100%"
  }
}));

const serviceList = [
  { id: 0, name: "Facebook" },
  { id: 1, name: "Twitter" },
  { id: 2, name: "Youtube" },
  { id: 3, name: "Reddit" }
];

function ListItmIcon(props) {
  switch (props.id) {
    case 0:
      return <FacebookIcon />;
    case 1:
      return <TwitterIcon />;
    case 2:
      return <YouTubeIcon />;
    case 3:
      return <RedditIcon />;
    default:
      return <span />;
  }
}

export default function CheckboxList() {
  const classes = useStyles();
  const [checked, setChecked] = React.useState([]);
  const [startIngestion, setStartIngestion] = React.useState(false);
  const [activeEdit, setActiveEdit] = React.useState(-1);

  const handleToggle = (value) => () => {
    const currentIndex = checked.indexOf(value);
    const newChecked = [...checked];

    if (currentIndex === -1) {
      newChecked.push(value);
    } else {
      newChecked.splice(currentIndex, 1);
    }

    setChecked(newChecked);
  };

  return (
    <Grid container spacing={3}>
      <Grid item xs={12} sm={3}>
        <List className={classes.root}>
          {serviceList.map((value) => {
            const labelId = `checkbox-list-label-${value.id}`;

            return (
              <ListItem
                key={value.id}
                role={undefined}
                dense
                button
                onClick={handleToggle(value.id)}
              >
                <ListItemIcon>
                  <Checkbox
                    edge="start"
                    checked={checked.indexOf(value.id) !== -1}
                    tabIndex={-1}
                    disableRipple
                    inputProps={{ "aria-labelledby": labelId }}
                  />
                </ListItemIcon>
                <ListItemText id={labelId} primary={value.name} />
                <ListItemSecondaryAction>
                  <ListItmIcon id={value.id} />
                </ListItemSecondaryAction>
              </ListItem>
            );
          })}
        </List>
      </Grid>
      <Grid item xs={12} sm={1}>
        <Button
          className={classes.transferButton}
          variant="outlined"
          color="primary"
          onClick={() => {
            setActiveEdit(checked[0]);
            console.log(checked);
          }}
        >
          <ArrowForwardIosIcon />
        </Button>
      </Grid>
      <Grid item xs={12} sm={6}>
        <IconButton aria-label="" className={classes.badgeContainer}>
          <StyledBadge
            className={classes.badgeContainer}
            badgeContent={activeEdit > -1 ? "f" : 0}
            color="secondary"
            anchorOrigin={{
              vertical: "top",
              horizontal: "left"
            }}
          >
            <div className={classes.contentBox}></div>
          </StyledBadge>
        </IconButton>
      </Grid>
      <Grid item xs={12} sm={2}>
        <Button variant="contained" color="primary">
          START INGESTION
        </Button>
      </Grid>
    </Grid>
  );
}
