import React, { Component } from 'react'
import axios from 'axios'
import  Page2layout from '../Layout/Page2layout'

class Mainlogic extends Component {
    constructor(props) {
        super(props);
        this.state ={
        Data:[],
        dict:{}, 
        dict2:{},   
        }
      }

  
    componentDidMount = () => {
        
        axios.get('http://52.175.201.248:3000/facebook/facebook_post/1').then(response =>{
            //console.log(response.data);
            //let commentcontdict={};
            this.setState({Data : response.data.list});


        });
        axios.get('http://52.175.201.248:3000/facebook/facebook_post_comments/1').then(response =>{
            //console.log(response.data.list);
            let commentcontdict={};
            let data_list=response.data.list
            let count = 0;
            //this.setState({Data : response.data.list});
            
            for(let i in response.data.list){
                //console.log(response.data.list[i]
                for(let j in response.data.list){
                     if(response.data.list[i].post_id == response.data.list[j].post_id){
                         count = count+1;
                     }   
                     
                }
                commentcontdict[response.data.list[i].post_id] = count ;
                count = 0;
            } 
            this.setState({dict : commentcontdict});
            //console.log(commentcontdict)
        
        });
        axios.get('http://52.175.201.248:3000/facebook/facebook_comments/1').then(response =>{
            //console.log(response.data.list);
            let commentcontdict={};
            let count = 0;
            let datearray=[];
            //this.setState({Data : response.data.list});
            
            for(let i in response.data.list){
                //console.log(response.data.list[i]
                let commentDate = response.data.list[i].created_datetime.split("T", 1);
                if (commentDate in commentcontdict){
                  let commentCount = commentcontdict[commentDate];
                  commentcontdict[commentDate] = commentCount + 1;
                } else {
                  commentcontdict[commentDate] = 1;
                }

            } /*
            for(let a in datearray){
                //console.log(response.data.list[i]
                for(let b in datearray){
                     if(datearray[a] === datearray[b]){
                         count = count+1;
                         console.log(count);
                     }   
                     
                }
                commentcontdict[datearray[a]] = count ;
                count = 0;
            } 
            */
            this.setState({dict2 : commentcontdict});
            console.log(datearray)
            console.log(commentcontdict)

        
        });

    }    
  render() {
    return (
      <div>
        <Page2layout
        postdata={this.state.Data}
        commentdic={this.state.dict}
        dailycommentdic={this.state.dict2}
        ></Page2layout>
      </div>
    )
  }
}

export default Mainlogic
