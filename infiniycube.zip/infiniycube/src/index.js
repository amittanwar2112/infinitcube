import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import  FullWidthTabs from './page2/demo';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import'bootstrap/dist/css/bootstrap.min.css';
import {Navbar,Nav,} from 'react-bootstrap';

ReactDOM.render(
  <React.StrictMode>
    <BrowserRouter>
        <main>
          <Navbar bg="dark" variant="dark" style={{backgroundColor:"black"}}>
            <Navbar.Brand href="#home" style={{color:"red",fontFamily:"terminator"}}>abc</Navbar.Brand>
            <Nav className="mr-auto">
            <Nav.Link href="/admin">Page1</Nav.Link>
            <Nav.Link href="/marketer">Page2</Nav.Link>
            </Nav>
          </Navbar>
            <Switch>
                <Route path="/" component={FullWidthTabs} exact />
                <Route path="/admin" component={FullWidthTabs} />
                <Route path="/marketer" component={App} />
            </Switch>
        </main>
    </BrowserRouter>, 
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
