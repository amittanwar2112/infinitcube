import React from 'react';
import './App.css';
import  Page2layout from './Layout/Page2layout'
import Mainlogic from './component/mainlogic'

function App() {
  return (
    <div >
      <Mainlogic></Mainlogic>
    </div>
  );
}

export default App;
